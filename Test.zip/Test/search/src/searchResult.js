import React from "react";

export default class DisplayResult extends React.Component {



    render() {
 
       
       
        return(
            
           <div>
               { 
                 this.props.imageURLs &&  this.props.imageURLs.forEach(element => 
                  <div>
                   <img src={element} ></img>
                   </div>
                 )
                }          
           </div>
                    
        )
    }
}