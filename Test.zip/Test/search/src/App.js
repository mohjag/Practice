import React, { Component } from 'react';
import SearchResult from "./search.js"

class App extends Component {
  render() {
    return (
      <div>
        <SearchResult />
       
      </div>
    );
  }
}

export default App;
